import joblib
import os
import pandas as pd

def model_fn(model_dir):
    """ Carga el modelo desde el artefacto """
    model_path = os.path.join(model_dir, "model.joblib")
    return joblib.load(model_path)

def input_fn(input_data, content_type):
    """ Procesa la entrada en formato CSV """
    if content_type == "text/csv":
        return pd.read_csv(input_data)
    else:
        raise ValueError(f"Unsupported content type: {content_type}")

def predict_fn(input_data, model):
    """ Realiza predicciones usando el modelo cargado """
    return model.predict(input_data)

def output_fn(prediction, accept):
    """ Devuelve la predicción como CSV """
    if accept == "text/csv":
        return ",".join(str(x) for x in prediction)
    else:
        raise ValueError(f"Unsupported accept type: {accept}")
